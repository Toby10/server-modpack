```json
{
  "title": "Pale Oak Sapling",
  "icon": "minecraft:pale_oak_sapling",
  "categories": [
    "minecraft:blocks",
    "minecraft:fertilizable",
    "minecraft:tag.saplings",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_sapling"
  ]
}
```

&spotlight(minecraft:pale_oak_sapling)
**Pale oak saplings** are the [pale oak](^minecraft:pale_oak_tree) variant of a [sapling](^minecraft:tag.saplings).

;;;;;

&title(Trading)
<|wandering-trader@minecraft:knowlogy_components|price=5,given-item=minecraft:pale_oak_sapling,given-quantity=,stock=8|>
