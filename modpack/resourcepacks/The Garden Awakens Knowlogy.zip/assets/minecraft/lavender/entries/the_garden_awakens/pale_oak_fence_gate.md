```json
{
  "title": "Pale Oak Fence gate",
  "icon": "minecraft:pale_oak_fence_gate",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.fence_gates",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_fence_gate"
  ]
}
```

&spotlight(minecraft:pale_oak_fence_gate)
**Pale Oak fence gates** are the [pale oak](^minecraft:pale_oak_tree) variant of [fence gates](^minecraft:tag.fence_gates).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_fence_gate>
