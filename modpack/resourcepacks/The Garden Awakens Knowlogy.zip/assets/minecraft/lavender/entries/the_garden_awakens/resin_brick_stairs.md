```json
{
  "title": "Resin Brick Stairs",
  "icon": "minecraft:resin_brick_stairs",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.stairs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:resin_brick_stairs"
  ]
}
```

&spotlight(minecraft:resin_brick_stairs)
**Resin brick stairs** are a [resin brick](^minecraft:resin_brick) variant of the [stairs](^minecraft:tag.stairs).

;;;;;

&title(Crafting)
<recipe;minecraft:resin_brick_stairs>
<recipe;minecraft:resin_brick_stairs_from_resin_bricks_stonecutting>