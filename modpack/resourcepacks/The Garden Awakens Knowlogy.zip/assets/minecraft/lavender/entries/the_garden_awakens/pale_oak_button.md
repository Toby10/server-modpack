```json
{
  "title": "Pale Oak Button",
  "icon": "minecraft:pale_oak_button",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.wooden_buttons",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_button"
  ]
}
```

&spotlight(minecraft:pale_oak_button)
**Pale Oak buttons** are the [pale oak](^minecraft:pale_oak_tree) variant of [wooden buttons](^minecraft:tag.wooden_buttons).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_button>
