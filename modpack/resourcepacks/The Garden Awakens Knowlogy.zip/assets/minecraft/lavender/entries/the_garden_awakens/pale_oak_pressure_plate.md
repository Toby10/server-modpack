```json
{
  "title": "Pale Oak Pressure Plate",
  "icon": "minecraft:pale_oak_pressure_plate",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.wooden_pressure_plates",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_pressure_plate"
  ]
}
```

&spotlight(minecraft:pale_oak_pressure_plate)
**Pale oak pressure plates** are the [pale oak](^minecraft:pale_oak_tree) variant of [wooden pressure plates](^minecraft:tag.wooden_pressure_plates).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_pressure_plate>
