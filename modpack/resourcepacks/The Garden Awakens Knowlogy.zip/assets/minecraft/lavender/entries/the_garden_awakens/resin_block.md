```json
{
  "title": "Block of Resin",
  "icon": "minecraft:resin_block",
  "categories": [
    "minecraft:blocks",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:resin_block"
  ]
}
```

&spotlight(minecraft:resin_block)
A **block of resin** is a block equivalent to nine [resin clumps](^minecraft:resin_clump).

;;;;;

&title(Crafting)
<recipe;minecraft:resin_block>