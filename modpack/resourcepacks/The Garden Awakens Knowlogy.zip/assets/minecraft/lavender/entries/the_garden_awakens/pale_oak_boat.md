```json
{
  "title": "Pale Oak Boat",
  "icon": "minecraft:pale_oak_boat",
  "categories": [
    "minecraft:items",
    "minecraft:tag.boats",
    "minecraft:group.tools_and_utilities"
  ],
  "associated_items": [
    "minecraft:pale_oak_boat",
    "minecraft:pale_oak_chest_boat"
  ]
}
```

&spotlight(minecraft:pale_oak_boat)
**Pale Oak boats** are the [pale oak](^minecraft:pale_oak_tree) variant of [boats](^minecraft:tag.boats).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_boat>
<recipe;minecraft:pale_oak_chest_boat>
