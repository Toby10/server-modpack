```json
{
  "title": "Resin Brick Wall",
  "icon": "minecraft:resin_brick_wall",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.walls",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:resin_brick_wall"
  ]
}
```

&spotlight(minecraft:resin_brick_wall)
A **resin brick wall** is a [resin brick](^minecraft:resin_brick) variant of a [wall](^minecraft:tag.walls).

;;;;;

&title(Crafting)
<recipe;minecraft:resin_brick_wall>
<recipe;minecraft:resin_brick_wall_from_resin_bricks_stonecutting>