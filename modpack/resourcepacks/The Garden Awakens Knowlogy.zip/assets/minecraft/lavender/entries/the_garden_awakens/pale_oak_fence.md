```json
{
  "title": "Pale Oak Fence",
  "icon": "minecraft:pale_oak_fence",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.wooden_fences",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_fence"
  ]
}
```

&spotlight(minecraft:pale_oak_fence)
**Pale Oak fences** are the [pale oak](^minecraft:pale_oak_tree) variant of [wooden fences](^minecraft:tag.wooden_fences).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_fence>
