```json
{
  "title": "Pale Hanging Moss",
  "icon": "minecraft:pale_hanging_moss",
  "categories": [
    "minecraft:blocks",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:pale_hanging_moss"
  ]
}
```

&spotlight(minecraft:pale_hanging_moss)
**Pale hanging moss** is a block found under the [logs](^minecraft:pale_oak_log) and [leaves](^minecraft:pale_oak_leaves) of [pale oaks](^minecraft:pale_oak_tree). When attached to a pale oak log or leaves, it emits ambient sounds.

;;;;;

&title(Breaking)
Pale hanging moss does not have an assigned tool. It drops itself only when mined with shears or a tool enchanted with Silk Touch, otherwise it drops nothing.

;;;;;

&title(Natural Generation)
Pale hanging moss generates under the leaves and logs of [pale oaks](^minecraft:pale_oak_tree) in [pale gardens](^minecraft:pale_garden). Pale hanging moss does not grow naturally after generating or being placed, but can grow longer if bone meal is is used on it.

;;;;;

&title(Trading)
<|wandering-trader@minecraft:knowlogy_components|price=5,given-item=minecraft:pale_hanging_moss,given-quantity=,stock=12|>

Pale hanging moss can be obtained by trading with a wandering trader, who may sell it for 1 emerald.

;;;;;

&title(Ambient Sounds)
Pale hanging moss emits subtle atmospheric sounds when it is attached to [pale oak leaves](^minecraft:pale_oak_leaves) or a [pale oak log](^minecraft:pale_oak_log).

;;;;;

&title(Composting)
Placing pale hanging moss into a composter has a 30% chance of raising the compost level by 1.