```json
{
  "title": "Pale Garden",
  "icon_sprite": "minecraft:icon/pale_garden",
  "categories": [
    "minecraft:tag.is_overworld",
    "minecraft:tag.is_forest",
    "minecraft:tag.has_structure.trial_chambers",
    "minecraft:biomes"
  ]
}
```

A **pale garden** is an [Overworld](^minecraft:tag.is_overworld) [forest](^minecraft:tag.is_forest) biome. It features [pale oaks](^minecraft:pale_oak_tree), [pale moss blocks](^minecraft:pale_moss_block), and [pale moss carpets](^minecraft:pale_moss_carpet). [Creaking hearts](^minecraft:creaking_heart) and their spawned [creakings](^minecraft:creaking) can be found here.

;;;;;

![Pale Garden](minecraft:textures/gui/image/pale_garden.png,fit)

[Pale oaks](^minecraft:pale_oak_tree) in a pale garden.

;;;;;

&title(Description)
The pale garden is a [biome](^minecraft:biomes) variant of the [dark forest](^minecraft:dark_forest), and they usually generate adjacent to dark forests. A pale garden consists of [pale oak trees](^minecraft:pale_oak_tree), with patches of [pale moss blocks](^minecraft:pale_moss_block), [pale moss carpets](^minecraft:pale_moss_carpet), and [eyeblossoms](^minecraft:eyeblossom) dotted around.

;;;;;

&title(Description)
[Pale hanging moss](^minecraft:pale_hanging_moss) can also be found hanging off the trees. Some of these trees may contain a [creaking heart block](^minecraft:creaking_heart), which spawns a [creaking](^minecraft:creaking)  when activated at night. The water, sky, and blocks of the biome are desaturated. Pale gardens do not generate [woodland mansions](^minecraft:woodland_mansion).

;;;;;

&title(Mobs)
[Creakings](^minecraft:creaking) are found in this [biome](^minecraft:biomes) only at night, but their spawning is controlled by [creaking hearts](^minecraft:creaking_heart), not the biome. Regular [passive mobs](^minecraft:passive_mobs) do not naturally spawn in the pale garden during the day, but normal [hostile mobs](^minecraft:hostile_mobs) can spawn here at night.
