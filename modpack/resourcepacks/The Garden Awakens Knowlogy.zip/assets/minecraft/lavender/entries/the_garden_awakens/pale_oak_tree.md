```json
{
  "title": "Pale Oak Tree",
  "icon_sprite": "minecraft:icon/pale_oak",
  "category": "minecraft:trees"
}
```

A **pale oak** is a type of [tree](^minecraft:trees) that generates in [pale gardens](^minecraft:pale_garden). Naturally-generated pale oaks have a chance of containing [creaking hearts](^minecraft:creaking_heart) in them. The trees have a similar shape to [dark oak](^minecraft:dark_oak_tree). Players can grow a pale oak by placing four [pale oak saplings](^minecraft:pale_oak_sapling) in a 2×2 square; pale oaks grown from saplings never contain creaking hearts.

;;;;;

&title(Appearance)
![Pale Oak Tree](minecraft:textures/gui/image/pale_oak_tree.png,fit)

;;;;;

&title(Appearance)
Pale oaks look like ordinary [dark oaks](^minecraft:dark_oak_tree), only in a gray shade with [pale hanging moss](^minecraft:pale_hanging_moss). You can also find a [creaking heart](^minecraft:creaking_heart) on pale oaks and [resin clump](^minecraft:resin_clump) if you hit a [creaking](^minecraft:creaking) near the creaking heart. Moreover, dark oaks do not generate creaking heart and pale hanging moss.

;;;;;

![Pale Garden](minecraft:textures/gui/image/pale_garden.png,fit)

Pale oaks in a [pale garden](^minecraft:pale_garden).

;;;;;

&title(Generation)
The pale oak only spawns naturally in the [pale garden](^minecraft:pale_garden) biome. It has a 10% chance to spawn a [creaking heart](^minecraft:creaking_heart). The spawn attempt fails if there is no log that is completely hidden by other logs. 

;;;;;

&title(Blocks and Items)
These items can be obtained from all variants of pale oak:
- [Pale Oak Log](^minecraft:pale_oak_log) (harvested with any tool including hands)
- [Pale Oak Leaves](^minecraft:pale_oak_leaves) (harvested with shears)
- [Pale Hanging Moss](^minecraft:pale_hanging_moss) (harvested with shears)
- [Stick](^minecraft:stick) (chance of dropping when breaking leaves)

;;;;;

&title(Blocks and Items)
- [Pale Oak Planks](^minecraft:pale_oak_planks) (created from a log in the inventory crafting grid)
- [Stripped Pale Oak Log](^minecraft:stripped_pale_oak_log) (created by using an axe on a log)
- [Pale Oak Sapling](^minecraft:pale_oak_sapling) (chance of dropping when breaking leaves)
- [Apple](^minecraft:apple) (chance of dropping when breaking leaves)