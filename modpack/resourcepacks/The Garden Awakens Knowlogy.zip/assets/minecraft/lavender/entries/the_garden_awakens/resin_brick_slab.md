```json
{
  "title": "Resin Brick Slab",
  "icon": "minecraft:resin_brick_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.slabs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:resin_brick_slab"
  ]
}
```

&spotlight(minecraft:resin_brick_slab)
A **resin brick slab** is a [resin brick](^minecraft:resin_brick) variant of a [slab](^minecraft:tag.slabs).

;;;;;

&title(Crafting)
<recipe;minecraft:resin_brick_slab>
<recipe;minecraft:resin_brick_slab_from_resin_bricks_stonecutting>
