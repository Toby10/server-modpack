```json
{
  "title": "Stripped Pale Oak Log",
  "icon": "minecraft:stripped_pale_oak_log",
  "categories": [
    "minecraft:blocks",
    "minecraft:stripped_log_blocks",
    "minecraft:tag.pale_oak_logs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:stripped_pale_oak_log"
  ]
}
```

&spotlight(minecraft:stripped_pale_oak_log)
**Pale Oak logs** are the [pale oak](^minecraft:pale_oak_tree) variant of a [stripped log](^minecraft:stripped_log_blocks).
