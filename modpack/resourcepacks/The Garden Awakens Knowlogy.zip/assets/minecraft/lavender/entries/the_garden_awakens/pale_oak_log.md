```json
{
  "title": "Pale Oak Log",
  "icon": "minecraft:pale_oak_log",
  "categories": [
    "minecraft:blocks",
    "minecraft:log_blocks",
    "minecraft:tag.pale_oak_logs",
    "minecraft:group.building_blocks",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_log"
  ]
}
```

&spotlight(minecraft:pale_oak_log)
**Pale Oak logs** are the [pale oak](^minecraft:pale_oak_tree) variant of a [log](^minecraft:log_blocks).
