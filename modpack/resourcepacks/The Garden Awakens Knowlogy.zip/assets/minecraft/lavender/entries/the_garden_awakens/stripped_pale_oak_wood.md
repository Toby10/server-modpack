```json
{
  "title": "Stripped Pale Oak Wood",
  "icon": "minecraft:stripped_pale_oak_wood",
  "categories": [
    "minecraft:blocks",
    "minecraft:stripped_wood_blocks",
    "minecraft:tag.pale_oak_logs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:stripped_pale_oak_wood"
  ]
}
```

&spotlight(minecraft:stripped_pale_oak_wood)
**Pale Oak wood** are the [pale oak](^minecraft:pale_oak_tree) variant of a [stripped wood](^minecraft:stripped_wood_blocks).
