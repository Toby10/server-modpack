```json
{
  "title": "Pale Oak Planks",
  "icon": "minecraft:pale_oak_planks",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.planks",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_planks"
  ]
}
```

&spotlight(minecraft:pale_oak_planks)
**Pale oak planks** are the [pale oak](^minecraft:pale_oak_tree) variant of [planks](^minecraft:tag.planks).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_planks>

;;;;;

&title(Crafting Ingredient)
<recipe;minecraft:pale_oak_stairs>
<recipe;minecraft:pale_oak_slab>