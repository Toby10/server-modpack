```json
{
  "title": "Pale Oak Slab",
  "icon": "minecraft:pale_oak_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.wooden_slabs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_slab"
  ]
}
```

&spotlight(minecraft:pale_oak_slab)
**Pale oak slabs** are the [pale oak](^minecraft:pale_oak_tree) variant of [wooden slabs](^minecraft:tag.wooden_slabs).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_slab>
