```json
{
  "title": "Creaking",
  "icon_sprite": "minecraft:icon/creaking",
  "categories": [
    "minecraft:mobs",
    "minecraft:hostile_mobs",
    "minecraft:group.spawn_eggs"
  ],
  "associated_items": [
    "minecraft:creaking_spawn_egg"
  ]
}
```

A **creaking** is a [hostile mob](^minecraft:hostile_mobs) spawned by active [creaking hearts](^minecraft:creaking_heart) at night or during thunderstorms. It moves and attacks via headbutting only when no Survival/Adventure mode players are looking at it, and otherwise remains completely stationary and motionless.

<entity;minecraft:creaking>

;;;;;

![Creaking in Pale Garden at Night](minecraft:textures/gui/image/creaking_in_pale-garden_at_night.png,fit)

A creaking at night.

;;;;;

&title(Damage Immunity)
It is protected from all damage by the creaking heart that spawned it; breaking it will instantly kill the creaking. Hitting a protected creaking causes [resin clumps](^minecraft:resin_clump) to grow near its linked creaking heart.