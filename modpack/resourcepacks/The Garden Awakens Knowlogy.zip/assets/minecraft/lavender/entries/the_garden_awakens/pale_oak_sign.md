```json
{
  "title": "Pale Oak Sign",
  "icon": "minecraft:pale_oak_sign",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.signs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_sign"
  ]
}
```

&spotlight(minecraft:pale_oak_sign)
**Pale oak signs** are the [pale oak](^minecraft:pale_oak_tree) variant of [signs](^minecraft:tag.signs).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_sign>
