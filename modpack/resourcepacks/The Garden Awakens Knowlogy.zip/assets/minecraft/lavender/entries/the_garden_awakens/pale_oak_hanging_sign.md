```json
{
  "title": "Pale Oak Hanging Sign",
  "icon": "minecraft:pale_oak_hanging_sign",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.hanging_signs",
    "minecraft:group.functional_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_hanging_sign"
  ]
}
```

&spotlight(minecraft:pale_oak_hanging_sign)
A **pale oak hanging sign** is a [pale oak](^minecraft:pale_oak_tree) wood [hanging sign](^minecraft:tag.hanging_signs) variant.

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_hanging_sign>

;;;;;

&title(Breaking)
Hanging signs can be broken with any [tool](^minecraft:tool) or without a tool, but an [axe](^minecraft:tag.axes) is fastest.

;;;;;

&title(Usage)
Hanging signs can be used to display text; they can be used to label storage, display information to other players or note areas of interest. Hanging signs are also not destroyed by water or lava and therefore may be used to control the flow of these fluids.