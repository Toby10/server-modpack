```json
{
  "title": "Resin Brick",
  "icon": "minecraft:resin_brick",
  "categories": [
    "minecraft:items",
    "minecraft:group.ingredients"
  ],
  "associated_items": [
    "minecraft:resin_brick"
  ]
}
```

&spotlight(minecraft:resin_brick)
A **resin brick** is a item used to create [resin bricks](^minecraft:resin_bricks). In addition, it can also be used as a [smithing](^minecraft:smithing) ingredient, giving orange details to pieces of armor.

;;;;;

&title(Crafting)
<recipe;minecraft:resin_brick>