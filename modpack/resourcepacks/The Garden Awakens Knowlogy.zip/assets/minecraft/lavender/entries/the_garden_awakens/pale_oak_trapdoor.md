```json
{
  "title": "Pale Oak Trapdoor",
  "icon": "minecraft:pale_oak_trapdoor",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.wooden_trapdoors",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_trapdoor"
  ]
}
```

&spotlight(minecraft:pale_oak_trapdoor)
**Pale oak trapdoors** are the [pale oak](^minecraft:pale_oak_tree) variant of [wooden trapdoors](^minecraft:tag.wooden_trapdoors).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_trapdoor>
