```json
{
  "title": "Resin Bricks",
  "icon": "minecraft:resin_bricks",
  "categories": [
    "minecraft:blocks",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:resin_bricks"
  ]
}
```

&spotlight(minecraft:resin_bricks)
**Resin bricks** is a block crafted from [resin brick](^minecraft:resin_brick). It can also be crafted into its block family, containing [slabs](^minecraft:resin_brick_slab), [stairs](^minecraft:resin_brick_stairs), [walls](^minecraft:resin_brick_wall) and the [chiseled variant](^minecraft:chiseled_resin_bricks).

;;;;;

&title(Crafting)
<recipe;minecraft:resin_bricks>