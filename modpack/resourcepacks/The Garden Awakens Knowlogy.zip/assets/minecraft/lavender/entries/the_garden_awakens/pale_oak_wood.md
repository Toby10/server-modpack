```json
{
  "title": "Pale Oak Wood",
  "icon": "minecraft:pale_oak_wood",
  "categories": [
    "minecraft:blocks",
    "minecraft:wood_blocks",
    "minecraft:tag.pale_oak_logs",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_wood"
  ]
}
```

&spotlight(minecraft:pale_oak_wood)
**Pale Oak wood** is the [pale oak](^minecraft:pale_oak_tree) variant of a [wood](^minecraft:wood_blocks).
