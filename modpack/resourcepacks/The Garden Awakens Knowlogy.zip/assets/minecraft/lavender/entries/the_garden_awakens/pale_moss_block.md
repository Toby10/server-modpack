```json
{
  "title": "Pale Moss Block",
  "icon": "minecraft:pale_moss_block",
  "categories": [
    "minecraft:blocks",
    "minecraft:fertilizable",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:pale_moss_block"
  ]
}
```

&spotlight(minecraft:pale_moss_block)
A **pale moss block** is a block that generates in [pale gardens](^minecraft:pale_garden).

;;;;;

&title(Breaking)
Pale moss blocks can be mined using any tool or by hand, but a hoe is the quickest way to break it.

;;;;;

&title(Natural Generation)
Pale moss blocks can be found on the ground inside of [pale gardens](^minecraft:pale_garden).

;;;;;

&title(Trading)
<|wandering-trader@minecraft:knowlogy_components|price=1,given-item=minecraft:pale_moss_block,given-quantity=2,stock=10|>

Pale moss blocks can be obtained by trading with a wandering trader, who may sell 2 for 1 emerald.

;;;;;

&title(Post-Generation)
When bone meal is used (<keybind;key.use>) on a pale moss block, moss spreads, if they have air blocks above them, in a corner-less 7×11×7 volume centered on the original pale moss block. Foliage can replace air on any of these blocks.

;;;;;

&title(Usage)
All plants can be placed on pale moss except for cacti and small dripleaves. Nether fungi can also be placed on it, but mushrooms can be placed only at light level 12 or below.

;;;;;

&title(Crafting Ingredient)
<recipe;pale_moss_carpet>

;;;;;

&title(Composting)
Placing a pale moss block into a composter has a 65% chance of raising the compost level by 1.

;;;;;

&title(Piston Interactivity)
Pale moss blocks are destroyed and dropped as items when pushed by pistons. They do not stick to sticky pistons, slime blocks, or honey blocks.
