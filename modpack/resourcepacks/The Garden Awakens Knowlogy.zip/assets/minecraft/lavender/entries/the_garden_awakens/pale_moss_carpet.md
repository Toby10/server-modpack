```json
{
  "title": "Pale Moss Carpet",
  "icon": "minecraft:pale_moss_carpet",
  "categories": [
    "minecraft:blocks",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:pale_moss_carpet"
  ]
}
```

&spotlight(minecraft:pale_moss_carpet)
A **pale moss carpet** is a block that causes vine-like pale moss to grow on the side of neighbouring blocks.

;;;;;

&title(Breaking)
Pale moss carpets can be mined using any tool or by hand, but a hoe is the quickest way to break it.

;;;;;

&title(Natural Generation)
Pale moss carpets can be found on the ground inside of [pale gardens](^minecraft:pale_garden).

;;;;;

&title(Crafting)
<recipe;pale_moss_carpet>

;;;;;

&title(Post-Generation)
Using bone meal on a [pale moss block](^minecraft:pale_moss_block) has a chance to grow pale moss carpets.

;;;;;

&title(Usage)
Similar to [moss carpets](^minecraft:moss_carpet), pale moss carpets have most of the properties of the standard carpets, except that it is not flammable, cannot be pushed by pistons, cannot be equipped on llamas, and does not occlude vibrations from [sculk sensors](^minecraft:sculk_sensor).

;;;;;

&title(Vines)
When placed next to a block, the pale moss carpet causes a vine texture to appear on the block's adjacent surfaces. If a second block is stacked above, when placed, the pale moss carpet has a chance to cause a two block tall vine texture to appear.

;;;;;

&title(Tweaking Vines)
The player may break the second vine texture to keep it at one block tall, or use bone meal on the carpet or the first vine texture to grow the second vine texture.

;;;;;

&title(Composting)
Placing a pale moss carpet into a composter has a 30% chance of raising the compost level by 1.
