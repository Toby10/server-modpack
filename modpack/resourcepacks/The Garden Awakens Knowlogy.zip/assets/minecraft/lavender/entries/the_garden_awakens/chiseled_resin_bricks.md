```json
{
  "title": "Chiseled Resin Bricks",
  "icon": "minecraft:chiseled_resin_bricks",
  "categories": [
    "minecraft:blocks",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:chiseled_resin_bricks"
  ]
}
```

&spotlight(minecraft:chiseled_resin_bricks)
**Chiseled resin bricks** are a variant of [resin bricks](^minecraft:resin_bricks), crafted from [resin brick slabs](^minecraft:resin_brick_slab).

;;;;;

&title(Crafting)
<recipe;minecraft:chiseled_resin_bricks>
<recipe;minecraft:chiseled_resin_bricks_from_resin_bricks_stonecutting>
