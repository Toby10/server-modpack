```json
{
  "title": "Pale Oak Door",
  "icon": "minecraft:pale_oak_door",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.wooden_doors",
    "minecraft:group.building_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_door"
  ]
}
```

&spotlight(minecraft:pale_oak_door)
**Pale Oak doors** are the [pale oak](^minecraft:pale_oak_tree) variant of [wooden doors](^minecraft:tag.wooden_doors).

;;;;;

&title(Crafting)
<recipe;minecraft:pale_oak_door>
