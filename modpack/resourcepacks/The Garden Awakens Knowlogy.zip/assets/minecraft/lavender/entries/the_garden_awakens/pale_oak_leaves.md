```json
{
  "title": "Pale Oak Leaves",
  "icon": "minecraft:pale_oak_leaves",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag.leaves",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:pale_oak_leaves"
  ]
}
```

&spotlight(minecraft:pale_oak_leaves)
**Pale oak leaves** are the [pale oak](^minecraft:pale_oak_tree) variant of a [leaves](^minecraft:tag.leaves).
