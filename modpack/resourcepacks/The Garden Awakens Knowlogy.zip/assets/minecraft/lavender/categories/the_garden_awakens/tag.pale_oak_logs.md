```json
{
  "title": "All Pale Oak Logs",
  "icon": "minecraft:pale_oak_log",
  "parent": "minecraft:wood_types"
}
```

[Logs](^minecraft:wood_types) derived from [pale oak trees](^minecraft:pale_oak_tree)

