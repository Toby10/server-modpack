```json
{
  "title": "Leaf litter",
  "icon": "minecraft:leaf_litter",
  "categories": [
    "minecraft:blocks",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:leaf_litter"
  ]
}
```

&spotlight(minecraft:leaf_litter)
**Leaf litter** is a thin decorative block resembling dead leaves. Up to four can be placed in the same block space.

;;;;;

&title(Natural Generatiob)
Leaf litter generates naturally in [forests](^minecraft:forest), [dark forests](^minecraft:dark_forest), and [wooded badlands](^minecraft:wooded_badlands).

;;;;;

&title(Smelting)
Leaf litter can be created by [smelting](^minecraft:smelting) any type of [leaves block](^minecraft:tag.leaves).
