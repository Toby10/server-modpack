```json
{
  "title": "Wildflowers",
  "icon": "minecraft:wildflowers",
  "categories": [
    "minecraft:blocks",
    "minecraft:fertilizable",
    "minecraft:group.natural_blocks"
  ],
  "associated_items": [
    "minecraft:wildflowers"
  ]
}
```

&spotlight(minecraft:wildflowers)
**Wildflowers** are a thin decorative [flower](^minecraft:tag.flowers) that can be placed four times in the space of one block, similar to [pink petals](^minecraft:pink_petals).


Up to four pieces of wildflowers can be placed in a single block space.

;;;;;

&title(Natural Generatiob)
Wildflowers generate naturally in [birch forests](^minecraft:birch_forest), [old growth birch forests](^minecraft:old_growth_birch_forest) and [meadows](^minecraft:meadow). Naturally generated wildflowers have a random number of flowers.

;;;;;

&title(Post-generation)
Each time [bone meal](^minecraft:bone_meal) is applied to wildflowers, they drop a copy of themselves, similar to [tall flowers](^minecraft:tag.tall_flowers).


Wildflowers also generate when bone meal is applied to a [grass block](^minecraft:grass_block) in [birch forests](^minecraft:birch_forest), [old growth birch forests](^minecraft:old_growth_birch_forest) and [meadows](^minecraft:meadow).‌

;;;;;

&title(Crafting Ingredient)
<recipe;minecraft:yellow_dye_from_wildflowers>

;;;;;

&title(Bees)
[Bees](^minecraft:bee) can pollinate wildflowers like other flowers. They can also be [bred](^minecraft:breeding) using wildflowers.

;;;;;

&title(Bee Nests)
[Oak](^minecraft:oak_tree), [birch](^minecraft:birch_tree), and [cherry trees](^minecraft:cherry_tree) grown from [saplings](^minecraft:tag.saplings) that are within 2 blocks of wildflowers have a 5% chance to grow with a [bee nest](^minecraft:bee_nest) containing 2-3 [bees](^minecraft:bee).

;;;;;

&title(Composting)
Placing into a [composter](^minecraft:composter) has a 30% chance of raising the compost level by 1.
